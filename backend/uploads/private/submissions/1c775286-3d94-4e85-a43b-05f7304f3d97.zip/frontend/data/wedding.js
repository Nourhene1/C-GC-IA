// ✏️ Modifiez ici les informations du mariage (date, lieu, WhatsApp...)
export const wedding = {
  // Date et heure du mariage (heure locale Tunisie, UTC+1)
  date: "2026-12-26T21:00:00+01:00",
  displayDate: {
    fr: "Samedi 26 Décembre 2026",
    en: "Saturday, December 26, 2026",
    ar: "السبت 26 ديسمبر 2026",
  },
  time: "21:00",
  venueName: {
    fr: "Nom de la salle",
    en: "Venue name",
    ar: "اسم القاعة",
  },
  address: {
    fr: "Adresse à confirmer, Tunisie",
    en: "Address to be confirmed, Tunisia",
    ar: "العنوان قيد التأكيد، تونس",
  },
  // Lien Google Maps (remplacez "Nom de la salle" par le vrai nom)
  mapsQuery: "Nom de la salle Tunisie",
  // Numéro WhatsApp pour recevoir les confirmations (format international, sans +)
  whatsappNumber: "21600000000",
};
