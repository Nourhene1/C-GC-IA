import LanguageSwitcher from "@/components/LanguageSwitcher";
import Hero from "@/components/Hero";
import Countdown from "@/components/Countdown";
import Program from "@/components/Program";
import Location from "@/components/Location";
import Rsvp from "@/components/Rsvp";
import Footer from "@/components/Footer";

export default function Page() {
  return (
    <main>
      <LanguageSwitcher />
      <Hero />
      <Countdown />
      <Program />
      <Location />
      <Rsvp />
      <Footer />
    </main>
  );
}
