"use client";

import { useLang } from "./LanguageProvider";
import { wedding } from "@/data/wedding";
import Reveal from "./Reveal";

export default function Program() {
  const { t, lang } = useLang();

  const events = [
    {
      time: "21:00",
      title: t.program.ceremony,
      text: t.program.ceremonyText,
    },
    {
      time: "23:00",
      title: t.program.dinner,
      text: t.program.dinnerText,
    },
  ];

  return (
    <section className="section program tinted" id="program">
      <Reveal>
        <h2 className="section-title">{t.program.title}</h2>
        <p className="program-date">{wedding.displayDate[lang]}</p>
      </Reveal>

      <div className="cards">
        {events.map((e, i) => (
          <Reveal key={e.title} delay={i * 150}>
            <article className="card">
              <span className="card-time" dir="ltr">
                {e.time}
              </span>
              <h3>{e.title}</h3>
              <p className="card-venue">{wedding.venueName[lang]}</p>
              <p className="card-text">{e.text}</p>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
