"use client";

import { createContext, useContext, useEffect, useState } from "react";
import fr from "@/locales/fr";
import en from "@/locales/en";
import ar from "@/locales/ar";

const dictionaries = { fr, en, ar };
export const LANGS = [
  { code: "fr", label: "FR" },
  { code: "ar", label: "عربي" },
  { code: "en", label: "EN" },
];

const LanguageContext = createContext({
  lang: "fr",
  t: fr,
  dir: "ltr",
  setLang: () => {},
});

export function LanguageProvider({ children }) {
  const [lang, setLangState] = useState("fr");

  // Récupère la langue enregistrée
  useEffect(() => {
    try {
      const saved = localStorage.getItem("lang");
      if (saved && dictionaries[saved]) setLangState(saved);
    } catch {}
  }, []);

  const dir = lang === "ar" ? "rtl" : "ltr";

  // Met à jour <html lang dir> et le titre de la page
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
    document.title = dictionaries[lang].meta.title;
  }, [lang, dir]);

  const setLang = (code) => {
    setLangState(code);
    try {
      localStorage.setItem("lang", code);
    } catch {}
  };

  return (
    <LanguageContext.Provider value={{ lang, dir, setLang, t: dictionaries[lang] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLang = () => useContext(LanguageContext);
