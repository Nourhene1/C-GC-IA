"use client";

import { useLang } from "./LanguageProvider";
import { wedding } from "@/data/wedding";

export default function Hero() {
  const { t, lang } = useLang();
  const names = lang === "ar" ? ["إيمان", "أحمد"] : ["Imen", "Ahmed"];

  return (
    <section className="hero" id="top">
      <div className="hero-bg" style={{ backgroundImage: "url(/images/hero.jpg)" }} />
      <div className="hero-veil" />
      <div className="hero-content">
        <p className="eyebrow fade-up" style={{ animationDelay: "0.1s" }}>
          {t.hero.eyebrow}
        </p>

        <h1 className="names fade-up" style={{ animationDelay: "0.3s" }}>
          <span>{names[0]}</span>
          <span className="amp">&amp;</span>
          <span>{names[1]}</span>
        </h1>

        <div className="divider fade-up" style={{ animationDelay: "0.5s" }}>
          <i />
          <b>✦</b>
          <i />
        </div>

        <p className="invite fade-up" style={{ animationDelay: "0.6s" }}>
          {t.hero.invite}
        </p>

        <p className="date-line fade-up" style={{ animationDelay: "0.8s" }}>
          {wedding.displayDate[lang]} · {wedding.time}
        </p>

        <blockquote className="verse fade-up" style={{ animationDelay: "1s" }}>
          <p>{t.hero.verse}</p>
          <cite>{t.hero.verseRef}</cite>
        </blockquote>

        <a href="#countdown" className="scroll-cta fade-up" style={{ animationDelay: "1.2s" }}>
          {t.hero.cta} <span aria-hidden>↓</span>
        </a>
      </div>
    </section>
  );
}
