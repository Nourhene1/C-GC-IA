"use client";

import { useState } from "react";
import { useLang } from "./LanguageProvider";
import { wedding } from "@/data/wedding";
import Reveal from "./Reveal";

export default function Rsvp() {
  const { t } = useLang();
  const [name, setName] = useState("");
  const [guests, setGuests] = useState(1);
  const [attending, setAttending] = useState(true);
  const [note, setNote] = useState("");
  const [error, setError] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    if (!name.trim()) {
      setError(true);
      return;
    }
    setError(false);
    const template = attending ? t.rsvp.whatsapp.yes : t.rsvp.whatsapp.no;
    let text = template.replace("{name}", name.trim()).replace("{guests}", guests);
    if (note.trim()) text += `\n\n${note.trim()}`;
    window.open(
      `https://wa.me/${wedding.whatsappNumber}?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer"
    );
  };

  return (
    <section className="section rsvp tinted" id="rsvp">
      <Reveal>
        <h2 className="section-title">{t.rsvp.title}</h2>
        <p className="rsvp-sub">{t.rsvp.subtitle}</p>
      </Reveal>

      <Reveal delay={150}>
        <form className="form" onSubmit={submit} noValidate>
          <label>
            <span>{t.rsvp.name}</span>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
            />
            {error && <em className="err">{t.rsvp.required}</em>}
          </label>

          <div className="choice">
            <button
              type="button"
              className={attending ? "active" : ""}
              onClick={() => setAttending(true)}
            >
              {t.rsvp.yes}
            </button>
            <button
              type="button"
              className={!attending ? "active" : ""}
              onClick={() => setAttending(false)}
            >
              {t.rsvp.no}
            </button>
          </div>

          {attending && (
            <label>
              <span>{t.rsvp.guests}</span>
              <input
                type="number"
                min="1"
                max="10"
                value={guests}
                onChange={(e) => setGuests(Math.max(1, Number(e.target.value) || 1))}
              />
            </label>
          )}

          <label>
            <span>{t.rsvp.message}</span>
            <textarea rows="3" value={note} onChange={(e) => setNote(e.target.value)} />
          </label>

          <button type="submit" className="btn solid">
            {t.rsvp.send}
          </button>
        </form>
      </Reveal>
    </section>
  );
}
