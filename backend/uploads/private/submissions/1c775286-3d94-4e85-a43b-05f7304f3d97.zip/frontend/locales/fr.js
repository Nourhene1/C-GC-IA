const fr = {
  meta: {
    title: "Imen & Ahmed — Invitation de Mariage",
    description: "Imen et Ahmed vous invitent à célébrer leur mariage.",
  },
  hero: {
    eyebrow: "Nous nous marions",
    verse:
      "Et parmi Ses signes, Il a créé pour vous des épouses issues de vous-mêmes, afin que vous trouviez le repos auprès d'elles.",
    verseRef: "Coran 30:21",
    invite: "Avec joie au cœur, nous vous invitons à célébrer notre mariage",
    cta: "Voir les détails",
  },
  countdown: {
    title: "Le grand jour approche",
    days: "Jours",
    hours: "Heures",
    minutes: "Min",
    seconds: "Sec",
    done: "C'est aujourd'hui ! 🤍",
  },
  program: {
    title: "Le programme",
    ceremony: "Cérémonie de mariage",
    ceremonyText: "Accueil des invités, musique et célébration",
    dinner: "Dîner & Soirée",
    dinnerText: "Danse et réjouissances jusqu'au bout de la nuit",
    at: "à",
  },
  location: {
    title: "Lieu de réception",
    open: "Ouvrir dans Maps",
  },
  rsvp: {
    title: "Confirmez votre présence",
    subtitle: "Votre présence rendra ce jour encore plus beau.",
    name: "Nom et prénom",
    guests: "Nombre de personnes",
    yes: "Je serai présent(e)",
    no: "Je ne pourrai pas venir",
    message: "Un petit mot pour les mariés (facultatif)",
    send: "Envoyer sur WhatsApp",
    required: "Veuillez saisir votre nom.",
    whatsapp: {
      yes: "Bonjour, c'est {name}. Je confirme ma présence au mariage d'Imen & Ahmed ({guests} personne(s)).",
      no: "Bonjour, c'est {name}. Malheureusement, je ne pourrai pas être présent(e) au mariage d'Imen & Ahmed.",
    },
  },
  footer: {
    thanks: "Merci d'avance de partager notre bonheur",
    made: "Avec amour",
  },
};

export default fr;
