"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { ArrowRight, Clock, UserCog, FolderKanban } from "lucide-react";
import RequireAuth from "@/components/auth/RequireAuth";
import AppShell from "@/components/layout/AppShell";
import Spinner from "@/components/ui/Spinner";
import { STATUS_STYLES } from "@/components/ui/StatusBadge";
import { btn, card, sectionTitle } from "@/components/ui/styles";
import { api } from "@/lib/api";

const STATUS_ORDER = ["en_attente", "en_revision", "valide", "rejete", "brouillon"];
const ROLE_ORDER = ["chef", "membre", "jury", "admin"];

function AdminHome() {
  const t = useTranslations("admin");
  const tc = useTranslations("common");
  const ts = useTranslations("status");
  const [stats, setStats] = useState(null);

  useEffect(() => {
    api("/api/admin/stats").then(setStats);
  }, []);

  if (!stats) return <Spinner />;

  const teams = Object.fromEntries(stats.teams.map((s) => [s._id, s.total]));
  const users = Object.fromEntries(stats.users.map((s) => [s._id, s.total]));
  const pending = teams.en_attente || 0;

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-2xl font-bold text-primary">{t("title")}</h1>

      {/* Appel à l'action : dossiers à examiner */}
      <Link href="/admin/teams?status=en_attente"
        className="flex items-center gap-4 rounded-2xl bg-primary p-6 text-white shadow-lg transition hover:bg-primary-dark">
        <Clock className="size-8 text-accent" />
        <span className="flex-1 text-lg font-bold">{t("pendingCta", { count: pending })}</span>
        <ArrowRight className="size-5" />
      </Link>

      <section className={card}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className={sectionTitle}><FolderKanban className="size-5 text-accent" /> {t("teams")}</h2>
          <Link href="/admin/teams" className={btn.outline}>{t("manageTeams")} <ArrowRight className="size-4" /></Link>
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {STATUS_ORDER.map((s) => (
            <Link key={s} href={`/admin/teams?status=${s}`}
              className={`rounded-xl p-4 transition hover:scale-[1.02] ${STATUS_STYLES[s]}`}>
              <p className="text-xs font-bold uppercase">{ts(s)}</p>
              <p className="text-3xl font-extrabold">{teams[s] || 0}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className={card}>
        <h2 className={sectionTitle}><UserCog className="size-5 text-accent" /> {t("users")}</h2>
        <div className="mt-5 grid gap-3 sm:grid-cols-4">
          {ROLE_ORDER.map((r) => (
            <div key={r} className="rounded-xl bg-surface p-4">
              <p className="text-xs font-bold uppercase text-slate-500">{tc(`roles.${r}`)}</p>
              <p className="text-3xl font-extrabold text-primary">{users[r] || 0}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default function AdminPage() {
  return (
    <RequireAuth roles={["admin"]}>
      {(user) => (
        <AppShell user={user}>
          <AdminHome />
        </AppShell>
      )}
    </RequireAuth>
  );
}
