# Module 2 — Inscription des équipes

Copie les dossiers `backend/` et `frontend/` par-dessus ton projet (remplace les fichiers existants).

## 1. Backend

```bash
cd backend
npm install multer nodemailer exceljs pdfkit
```

Ajoute dans `backend/.env` (voir `.env.example`) :

```
FRONTEND_URL=http://localhost:3000
MAX_UPLOAD_MB=5
SMTP_HOST=
```

Avec `SMTP_HOST` vide, les emails ne partent pas : ils s'affichent dans le terminal du backend,
avec les liens de confirmation et d'invitation à copier dans le navigateur.

Puis :

```bash
npm run create-edition   # met à jour l'édition 2026 (pièces demandées, taille des équipes)
npm run dev
```

## 2. Frontend

Rien à installer. Vérifie juste que `frontend/.env.local` contient `NEXT_PUBLIC_API_URL=http://localhost:5000`.

```bash
cd frontend
npm run dev
```

## 3. Nettoyer la base

Les comptes et équipes créés pendant tes tests précédents n'ont pas les nouveaux champs.
Dans MongoDB Compass, vide les collections `users` (sauf l'admin) et `teams`.

## Parcours à tester

1. `/register` → le chef crée son compte → lien de confirmation dans le terminal backend
2. `/verify-email?token=…` → compte confirmé → `/team/new`
3. Création de l'équipe → `/team`
4. Ajout d'un membre → lien d'activation dans le terminal → `/activate?token=…`
5. Dépôt des pièces justificatives → « Soumettre mon dossier »
6. Admin (`admin@iagc.tn`) → `/admin/teams` → Examiner → Valider / Révision / Rejeter
7. Exports CSV, Excel et PDF depuis `/admin/teams`
