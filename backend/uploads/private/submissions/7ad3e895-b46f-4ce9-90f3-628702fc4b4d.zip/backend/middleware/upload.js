import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import { PRIVATE_DIR, LOGO_DIR } from "../utils/files.js";

const MB = 1024 * 1024;

// Crée un middleware d'envoi d'un seul fichier (champ "file")
function makeUpload({ dir, types, maxMb }) {
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    // Nom aléatoire : on ne garde jamais le nom choisi par l'utilisateur sur le disque
    filename: (req, file, cb) => {
      cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase());
    },
  });

  return multer({
    storage,
    limits: { fileSize: maxMb * MB, files: 1 },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      // L'extension ET le type annoncé doivent correspondre à la liste autorisée
      if (types[ext] !== file.mimetype) {
        const err = new Error("INVALID_FILE_TYPE");
        err.code = "INVALID_FILE_TYPE";
        return cb(err);
      }
      cb(null, true);
    },
  }).single("file");
}

// F2.4 : pièces justificatives -> PDF, JPG ou PNG, 5 Mo par défaut
export const uploadDocument = makeUpload({
  dir: PRIVATE_DIR,
  types: {
    ".pdf": "application/pdf",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
  },
  maxMb: Number(process.env.MAX_UPLOAD_MB) || 5,
});

// F2.2 : logo de l'équipe -> image de 2 Mo maximum
export const uploadLogo = makeUpload({
  dir: LOGO_DIR,
  types: {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
  },
  maxMb: 2,
});
