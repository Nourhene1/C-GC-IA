import path from "node:path";
import fs from "node:fs/promises";

// Dossier racine des fichiers envoyés
export const UPLOAD_ROOT = path.resolve("uploads");
export const PRIVATE_DIR = path.join(UPLOAD_ROOT, "private");      // pièces justificatives
export const LOGO_DIR = path.join(UPLOAD_ROOT, "public", "logos"); // logos (publics)

// Supprime un fichier sans planter s'il n'existe plus
export async function removeFile(absPath) {
  if (!absPath) return;
  try {
    await fs.unlink(absPath);
  } catch (err) {
    if (err.code !== "ENOENT") console.error("Suppression impossible :", err.message);
  }
}

export const privatePath = (fileName) => path.join(PRIVATE_DIR, path.basename(fileName));

// "/uploads/logos/abc.png" -> chemin absolu sur le disque
export const logoPath = (publicUrl) =>
  publicUrl ? path.join(LOGO_DIR, path.basename(publicUrl)) : null;
