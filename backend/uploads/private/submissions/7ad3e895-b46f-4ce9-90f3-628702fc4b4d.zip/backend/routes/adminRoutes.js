import { Router } from "express";
import { protect, authorize } from "../middleware/auth.js";
import {
  getStats, listTeams, getTeam, updateStatus, exportTeams,
} from "../controllers/adminTeamController.js";

const router = Router();

// Toutes les routes de ce fichier : connecté ET admin
router.use(protect, authorize("admin"));

router.get("/stats", getStats);
router.get("/teams", listTeams);                    // F2.6 : liste des dossiers
router.get("/teams/export", exportTeams);           // F2.9 : avant "/teams/:id" !
router.get("/teams/:id", getTeam);
router.patch("/teams/:id/status", updateStatus);    // F2.6 + F2.7

export default router;
