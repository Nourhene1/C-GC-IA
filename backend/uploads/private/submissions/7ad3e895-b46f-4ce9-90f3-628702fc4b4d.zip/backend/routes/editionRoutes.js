import { Router } from "express";
import Edition from "../models/Edition.js";

const router = Router();

// GET /api/editions/current : l'édition en cours (public)
router.get("/current", async (req, res) => {
  const edition = await Edition.findOne({ isCurrent: true }).lean();
  if (!edition) return res.status(404).json({ code: "NO_EDITION" });
  res.json({ edition, now: new Date() });
});

// GET /api/editions/archives : les éditions passées
router.get("/archives", async (req, res) => {
  const editions = await Edition.find({ isCurrent: false })
    .sort({ year: -1 })
    .select("year title theme stats")
    .lean();
  res.json({ editions });
});

export default router;
