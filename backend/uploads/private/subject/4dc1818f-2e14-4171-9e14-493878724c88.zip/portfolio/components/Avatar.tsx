"use client";
import { motion } from "framer-motion";

export function Avatar() {
  return (
    <div className="relative w-72 h-72 md:w-80 md:h-80">
      {/* Spinning gold ring */}
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{
          background: "conic-gradient(from 0deg, #C9A84C, #E8C97A, #A07830, #E8C97A, #C9A84C)",
          padding: "3px",
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
      >
        <div className="w-full h-full rounded-full bg-white dark:bg-zinc-950" />
      </motion.div>

      {/* Avatar SVG */}
      <div className="absolute inset-[4px] rounded-full overflow-hidden bg-gradient-to-br from-zinc-900 via-zinc-800 to-zinc-900">
        <svg viewBox="0 0 320 320" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
          <defs>
            <radialGradient id="bgGrad" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#1c1c1c" />
              <stop offset="100%" stopColor="#0a0a0a" />
            </radialGradient>
            <radialGradient id="skinGrad" cx="50%" cy="40%" r="55%">
              <stop offset="0%" stopColor="#f5c99a" />
              <stop offset="100%" stopColor="#d4956a" />
            </radialGradient>
            <linearGradient id="shirtGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1a1a1a" />
              <stop offset="50%" stopColor="#2a2a2a" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
            <linearGradient id="goldAccent" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#C9A84C" />
              <stop offset="50%" stopColor="#E8C97A" />
              <stop offset="100%" stopColor="#A07830" />
            </linearGradient>
          </defs>

          {/* Background */}
          <circle cx="160" cy="160" r="160" fill="url(#bgGrad)" />

          {/* Decorative gold particles */}
          <circle cx="55" cy="75" r="2.5" fill="#C9A84C" opacity="0.7" />
          <circle cx="265" cy="90" r="2" fill="#E8C97A" opacity="0.6" />
          <circle cx="38" cy="200" r="1.5" fill="#C9A84C" opacity="0.4" />
          <circle cx="285" cy="210" r="2.5" fill="#E8C97A" opacity="0.5" />
          <circle cx="95" cy="45" r="1.5" fill="#C9A84C" opacity="0.3" />
          <circle cx="230" cy="55" r="1.5" fill="#E8C97A" opacity="0.3" />

          {/* Gold diamond shapes */}
          <polygon points="50,155 57,148 64,155 57,162" fill="#C9A84C" opacity="0.25" />
          <polygon points="258,175 265,168 272,175 265,182" fill="#E8C97A" opacity="0.25" />

          {/* Code decoration */}
          <text x="25" y="172" fontSize="22" fill="#C9A84C" opacity="0.35" fontFamily="monospace" fontWeight="bold">{"{"}</text>
          <text x="274" y="172" fontSize="22" fill="#C9A84C" opacity="0.35" fontFamily="monospace" fontWeight="bold">{"}"}</text>

          {/* Body / jacket */}
          <ellipse cx="160" cy="295" rx="95" ry="65" fill="url(#shirtGrad)" />
          <ellipse cx="160" cy="268" rx="80" ry="58" fill="url(#shirtGrad)" />

          {/* Gold tie / necklace accent */}
          <polygon points="160,228 152,248 160,268 168,248" fill="url(#goldAccent)" opacity="0.9" />

          {/* Neck */}
          <rect x="144" y="194" width="32" height="36" rx="8" fill="url(#skinGrad)" />

          {/* Head */}
          <ellipse cx="160" cy="163" rx="66" ry="73" fill="url(#skinGrad)" />

          {/* Hair — dark sophisticated */}
          <ellipse cx="160" cy="100" rx="66" ry="40" fill="#111" />
          <ellipse cx="107" cy="128" rx="20" ry="36" fill="#111" />
          <ellipse cx="213" cy="128" rx="20" ry="36" fill="#111" />
          {/* Hair shine */}
          <ellipse cx="143" cy="98" rx="18" ry="9" fill="#2a2a2a" opacity="0.6" />

          {/* Eyebrows */}
          <path d="M128 136 Q143 128 156 133" stroke="#1a1a1a" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          <path d="M164 133 Q177 128 192 136" stroke="#1a1a1a" strokeWidth="3.5" strokeLinecap="round" fill="none" />

          {/* Eyes */}
          <ellipse cx="142" cy="152" rx="13" ry="13" fill="white" />
          <ellipse cx="178" cy="152" rx="13" ry="13" fill="white" />
          <circle cx="143" cy="153" r="9" fill="#2c1a00" />
          <circle cx="179" cy="153" r="9" fill="#2c1a00" />
          {/* Gold iris highlight */}
          <circle cx="144" cy="152" r="4.5" fill="#C9A84C" opacity="0.6" />
          <circle cx="180" cy="152" r="4.5" fill="#C9A84C" opacity="0.6" />
          <circle cx="146" cy="150" r="2" fill="white" />
          <circle cx="182" cy="150" r="2" fill="white" />

          {/* Nose */}
          <path d="M154 166 Q160 180 166 166" stroke="#c08060" strokeWidth="2" strokeLinecap="round" fill="none" />

          {/* Smile */}
          <path d="M141 188 Q160 203 179 188" stroke="#c08060" strokeWidth="2.5" strokeLinecap="round" fill="none" />

          {/* Ears */}
          <ellipse cx="94" cy="160" rx="10" ry="13" fill="url(#skinGrad)" />
          <ellipse cx="226" cy="160" rx="10" ry="13" fill="url(#skinGrad)" />

          {/* Gold earring left */}
          <circle cx="94" cy="168" r="3" fill="url(#goldAccent)" />

          {/* Laptop icon on shirt */}
          <rect x="137" y="258" width="46" height="28" rx="3" fill="#0a0a0a" opacity="0.8" />
          <rect x="130" y="284" width="60" height="4" rx="2" fill="#0a0a0a" opacity="0.6" />
          {/* Gold code text */}
          <text x="144" y="277" fontSize="9" fill="#C9A84C" fontFamily="monospace" fontWeight="bold">{"</>"}</text>
        </svg>
      </div>

      {/* Gold badge */}
      <motion.div
        className="absolute -bottom-2 -right-2 text-zinc-900 text-xs font-bold px-3 py-1.5 rounded-full shadow-lg border-2 border-zinc-900 dark:border-zinc-950"
        style={{ background: "linear-gradient(135deg, #C9A84C, #E8C97A)" }}
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.8, type: "spring" }}
      >
        ⚡ Full-Stack Dev
      </motion.div>
    </div>
  );
}
