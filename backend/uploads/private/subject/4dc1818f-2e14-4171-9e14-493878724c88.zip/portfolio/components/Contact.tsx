"use client";
import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { GitFork, Link2, Mail, Send, CheckCircle2 } from "lucide-react";
import { Translations } from "@/lib/translations";

export function Contact({ t }: { t: Translations }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    await new Promise((r) => setTimeout(r, 1200));
    setSending(false);
    setSent(true);
  };

  return (
    <section id="contact" className="py-28 bg-white dark:bg-zinc-950">
      <div className="max-w-4xl mx-auto px-6" ref={ref}>
        <div className="text-center mb-14">
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            className="inline-block text-sm font-bold uppercase tracking-widest mb-4"
            style={{ color: "#C9A84C" }}
          >
            {t.contact.label}
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 10 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-display font-black text-zinc-900 dark:text-white mb-4"
          >
            {t.contact.title}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-zinc-500 dark:text-zinc-400 text-lg max-w-lg mx-auto"
          >
            {t.contact.subtitle}
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="rounded-3xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900 p-8 md:p-12"
        >
          {sent ? (
            <div className="text-center py-10">
              <CheckCircle2 size={56} className="mx-auto mb-4" style={{ color: "#C9A84C" }} />
              <p className="text-zinc-700 dark:text-zinc-300 text-lg font-medium">{t.contact.success}</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 dark:text-zinc-300 mb-2">
                    {t.contact.name}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder={t.contact.namePlaceholder}
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-600 text-sm focus:outline-none transition-colors"
                    style={{ "--tw-ring-color": "#C9A84C" } as React.CSSProperties}
                    onFocus={e => e.target.style.borderColor = "#C9A84C"}
                    onBlur={e => e.target.style.borderColor = ""}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-zinc-700 dark:text-zinc-300 mb-2">
                    {t.contact.email}
                  </label>
                  <input
                    type="email"
                    required
                    placeholder={t.contact.emailPlaceholder}
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-600 text-sm focus:outline-none transition-colors"
                    onFocus={e => e.target.style.borderColor = "#C9A84C"}
                    onBlur={e => e.target.style.borderColor = ""}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-zinc-700 dark:text-zinc-300 mb-2">
                  {t.contact.message}
                </label>
                <textarea
                  required
                  rows={5}
                  placeholder={t.contact.messagePlaceholder}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 dark:placeholder-zinc-600 text-sm focus:outline-none transition-colors resize-none"
                  onFocus={e => e.target.style.borderColor = "#C9A84C"}
                  onBlur={e => e.target.style.borderColor = ""}
                />
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                <button
                  type="submit"
                  disabled={sending}
                  className="flex items-center gap-2 px-8 py-3.5 rounded-full font-semibold text-sm text-zinc-950 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200 disabled:opacity-60"
                  style={{ background: "linear-gradient(135deg, #C9A84C, #E8C97A, #A07830)" }}
                >
                  <Send size={15} />
                  {sending ? t.contact.sending : t.contact.send}
                </button>

                <div className="flex items-center gap-4">
                  <span className="text-sm text-zinc-400">{t.contact.orReach}</span>
                  <div className="flex gap-3">
                    {[
                      { Icon: GitFork, href: "https://github.com" },
                      { Icon: Link2, href: "https://linkedin.com" },
                      { Icon: Mail, href: "mailto:alex@example.com" },
                    ].map(({ Icon, href }, i) => (
                      <a
                        key={i}
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-9 h-9 rounded-full border border-zinc-300 dark:border-zinc-700 flex items-center justify-center text-zinc-500 dark:text-zinc-400 hover:border-gold hover:text-gold transition-all"
                      >
                        <Icon size={15} />
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  );
}
