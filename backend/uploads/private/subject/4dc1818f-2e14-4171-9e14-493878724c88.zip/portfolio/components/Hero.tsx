"use client";
import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";
import { Avatar } from "./Avatar";
import { Translations } from "@/lib/translations";

export function Hero({ t }: { t: Translations }) {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
      {/* Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-50 via-white to-zinc-100 dark:from-zinc-950 dark:via-zinc-900 dark:to-black" />
        {/* Gold glows */}
        <div className="absolute top-1/4 -left-40 w-[500px] h-[500px] rounded-full blur-3xl opacity-20 dark:opacity-10"
          style={{ background: "radial-gradient(circle, #C9A84C, transparent)" }} />
        <div className="absolute bottom-1/4 -right-40 w-[400px] h-[400px] rounded-full blur-3xl opacity-10 dark:opacity-10"
          style={{ background: "radial-gradient(circle, #E8C97A, transparent)" }} />
        {/* Subtle dot grid */}
        <div
          className="absolute inset-0 opacity-[0.04] dark:opacity-[0.06]"
          style={{
            backgroundImage: "radial-gradient(circle, #C9A84C 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />
      </div>

      <div className="max-w-6xl mx-auto px-6 w-full py-20">
        <div className="flex flex-col-reverse lg:flex-row items-center gap-16 lg:gap-24">
          {/* Text */}
          <div className="flex-1 text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 border text-xs font-semibold px-4 py-2 rounded-full mb-6"
              style={{ borderColor: "#C9A84C44", color: "#C9A84C", background: "#C9A84C11" }}
            >
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              {t.hero.available}
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-zinc-500 dark:text-zinc-400 text-lg mb-2 font-medium"
            >
              {t.hero.greeting}
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-5xl md:text-7xl font-display font-black tracking-tight mb-3 gold-text"
            >
              {t.hero.name}
            </motion.h1>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="text-2xl md:text-3xl font-display font-bold text-zinc-700 dark:text-zinc-200 mb-6"
            >
              {t.hero.title}
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="text-zinc-500 dark:text-zinc-400 text-lg leading-relaxed max-w-lg mx-auto lg:mx-0 mb-10"
            >
              {t.hero.subtitle}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <button
                onClick={() => document.querySelector("#projects")?.scrollIntoView({ behavior: "smooth" })}
                className="px-8 py-3.5 font-semibold rounded-full text-sm text-zinc-950 hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
                style={{ background: "linear-gradient(135deg, #C9A84C, #E8C97A, #A07830)" }}
              >
                {t.hero.cta}
              </button>
              <button
                onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
                className="px-8 py-3.5 border font-semibold rounded-full text-sm text-zinc-700 dark:text-zinc-300 hover:-translate-y-0.5 transition-all duration-200"
                style={{ borderColor: "#C9A84C66" }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = "#C9A84C")}
                onMouseLeave={e => (e.currentTarget.style.borderColor = "#C9A84C66")}
              >
                {t.hero.ctaContact}
              </button>
            </motion.div>
          </div>

          {/* Avatar */}
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex-shrink-0"
          >
            <Avatar />
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
          style={{ color: "#C9A84C" }}
        >
          <motion.div animate={{ y: [0, 6, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>
            <ArrowDown size={18} />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
